package service;

import java.util.List;

import org.hibernate.Session;

import DAO.UserDAO;
import model.User;

public class UserService {
	
	UserDAO ud = new UserDAO();

	public User login(Session session,String username, String password) {
		// TODO Auto-generated method stub
		User u = ud.findByUsername(session,username);
		if(u==null) {
			return null;
		}
		else if (u.getPasswd().equals(password))
		{
			return u;
		}
		else {
			return null;
		}
	}

	public void register(Session session, User u1) {
		// TODO Auto-generated method stub
		ud.saveUser(session,u1);
	}

	public List<User> getAllUsers(Session session) {
		// TODO Auto-generated method stub
		return ud.getAll(session);
	}

	public void resetPasswd(Session session, User u) {
		// TODO Auto-generated method stub
		ud.resetPasswd(session,u);
		
	}


}
