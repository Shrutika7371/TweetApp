package Main;

import model.Tweet;
import model.User;
import service.TweetService;
import service.UserService;

import java.util.Date;
import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import config.HibernateConfigure;

public class Main {

	static UserService us = new UserService();

	static TweetService ts = new TweetService();

	public static void main(String[] args) {
		Session session = HibernateConfigure.getSessionFactory().openSession();
		User u;
		Scanner sc = new Scanner(System.in);
		while(true){
		System.out.println("Enter choice \n1.Login\n2.Register\n3.Forgot password");
		int ch = sc.nextInt();
		switch(ch) {
		case 1: 
			 System.out.println("Enter Username:");
			 String username= sc.next();
			 System.out.println("Enter Password:");
			 String password= sc.next();	
			 u= us.login(session,username,password);
			 int ch1=0;
			 if(u!=null)
			 {
				do{
				ch1=0;
					System.out.println("Enter choice \n1. Post a tweet\r\n"
							+ "\r\n"
							+ "2. View my tweets\r\n"
							+ "\r\n"
							+ "3. View all tweets\r\n"
							+ "\r\n"
							+ "4. View All Users\r\n"
							+ "\r\n"
							+ "5. Reset Password\r\n"
							+ "\r\n"
							+ "6. Logout");
					 ch1 = sc.nextInt();
					switch(ch1) {
					case 1: //post a tweet
						Tweet obj = new Tweet();
						
						System.out.println("Enter message you want to tweet");
						 sc.next();
						String tweetmsg = sc.nextLine();
						obj.setTweetMsg(tweetmsg);
						obj.setUserName(u.getUserName());
						ts.saveTweet(session,obj);
						break;
						
					case 2: //view my tweets
						List<Tweet> mytweets=ts.getallbyusername(session,u.getUserName());
						mytweets.forEach(tweet->System.out.println(tweet));
						break;
						
					case 3: //view all tweets
						List<Tweet> alltweets= ts.getAlltweets(session);
						alltweets.forEach(tweet->System.out.println(tweet));
						break;
						
					case 4: //view all users
						List<User> allusers = us.getAllUsers(session);
						allusers.forEach(user->System.out.println(user));
						break;
						
					case 5: break;
					
					case 6://logout
						u=null;
						System.out.println("logged out successfully");
						break;
							
					}
					
				
			 }while(ch1!=6);
			 }
				break;
		case 2: System.out.println("Enter fName:");
				String fname= sc.next();
				System.out.println("Enter Lname:");
				String lname= sc.next();	
				System.out.println("Enter gender:");
				String gender= sc.next();	
				System.out.println("Enter Username:");
				 String uname= sc.next();
				 System.out.println("Enter Password:");
				 String passwd= sc.next();
				User u1 = new User();
				u1.setFirstName(fname);
				u1.setLastName(lname);
				u1.setGender(gender);
				u1.setPasswd(passwd);
				u1.setUserName(uname);
				us.register(session,u1);
				break;
		 default:
			 System.out.println("Enter correct choice");
			 break;
		}
		}
		

	
	}

}
