package DAO;

import model.Tweet;
import model.User;

import java.util.List;

import org.hibernate.Session;

import org.hibernate.Transaction;
import org.hibernate.query.Query;

public class UserDAO {

	
   public User findByUsername(Session session,String username) {
	   User user=null;
	   try {
      Transaction t = session.beginTransaction();
      Query<User> query=session.createQuery("from User where userName= :uname1", User.class);
      query.setParameter("uname1",username);
       user = query.getSingleResult();
      t.commit();
      return user;
	   }catch(Exception E) {
		   
	   }
	   return user;
   }

public void saveUser(Session session, User u1) {
	
	 Transaction t = session.beginTransaction();
     System.out.println("User dao"+u1);
     session.save(u1);
     t.commit();
}

public List<User> getAll(Session session) {
	// TODO Auto-generated method stub
	Transaction t = session.beginTransaction();
	Query<User> query=session.createQuery("from User", User.class);
     List<User> allusers=query.getResultList();
     t.commit();
	return allusers;
}

public void resetPasswd(Session session, User ud) {
	// TODO Auto-generated method stub
	Transaction t = session.beginTransaction();
	session.saveOrUpdate(ud);
    
     t.commit();
}


	
}
