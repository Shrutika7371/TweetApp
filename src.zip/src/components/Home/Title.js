import React, { Component } from "react";
import Login from "../Login/Login";
import SignUp from "../Signup/SignUp";
import "./Title.css";

window.sessionStorage.clear();
class Title extends Component {

  render() {
    return (
      <div className="container wrapper">
        
        <div className="card cardlogin" id ="card">
          <Login />
        </div>
        <div className="card cardsignup" id ="card">
          <SignUp />
        </div>
      </div>
    );
  }
}

export default Title;
